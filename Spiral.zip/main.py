import turtle
import math
import random
wn = turtle.Screen()
wn.bgcolor('charcoal')
Albert = turtle.Turtle()
Albert.speed(0)
Albert.color('blue')
rotate=int(360)
def drawCircles(t,size):
    for i in range(20):
        t.circle(size)
        size=size-20
def drawSpecial(t,size,repeat):
  for i in range (repeat):
    drawCircles(t,size)
    t.right(360/repeat)
drawSpecial(Albert,100,10)
Steve = turtle.Turtle()
Steve.speed(0)
Steve.color('white')
rotate=int(90)
def drawCircles(t,size):
    for i in range(15):
        t.circle(size)
        size=size-4
def drawSpecial(t,size,repeat):
    for i in range (repeat):
        drawCircles(t,size)
        t.right(360/repeat)
drawSpecial(Steve,100,10)
Barry = turtle.Turtle()
Barry.speed(0)
Barry.color('green')
rotate=int(80)
def drawCircles(t,size):
    for i in range(16):
        t.circle(size)
        size=size-16
def drawSpecial(t,size,repeat):
    for i in range (repeat):
        drawCircles(t,size)
        t.right(360/repeat)
drawSpecial(Barry,100,10)
Terry = turtle.Turtle()
Terry.speed(0)
Terry.color('fuschia')
rotate=int(90)
def drawCircles(t,size):
    for i in range(10):
        t.circle(size)
        size=size-19
def drawSpecial(t,size,repeat):
    for i in range (repeat):
        drawCircles(t,size)
        t.right(360/repeat)
drawSpecial(Terry,100,10)
Will = turtle.Turtle()
Will.speed(0)
Will.color('yellow')
rotate=int(90)
def drawCircles(t,size):
    for i in range(8):
        t.circle(size)
        size=size-20
def drawSpecial(t,size,repeat):
    for i in range (repeat):
        drawCircles(t,size)
        t.right(360/repeat)
drawSpecial(Will,100,10)
Lee = turtle.Turtle()
Lee.speed(0)
Lee.color('purple')
rotate=int(90)
def drawCircles(t,size):
    for i in range(7):
        t.circle(size)
        size=size-4
def drawSpecial(t,size,repeat):
    for i in range (repeat):
        drawCircles(t,size)
        t.right(360/repeat)
drawSpecial(Lee,100,10)